# TINMAN TRADING — Website

Bilingual (EN / 繁中) corporate landing page.

## Deploy to GitHub Pages

1. Create a new public repository on GitHub
2. Upload **all files in this folder** (preserve the `assets/` subfolder)
3. Go to **Settings → Pages → Source → Deploy from a branch → main / root → Save**
4. Your site goes live at https://YOUR-USERNAME.github.io/REPO-NAME/

## Files

- `index.html` — entry point
- `styles.css` — all styles
- `*.jsx` — React components (transpiled in-browser via Babel)
- `assets/hero-bg.png` — hero background image

## Local preview

Just open `index.html` in a browser — no build step required.

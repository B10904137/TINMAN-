// TINMAN — i18n (EN ↔ zh-TW)
// Centralised translations + React context. Other scripts read via window.useLang().

const translations = {
  en: {
    nav: {
      why: "Why TINMAN",
      cap: "Capabilities",
      about: "About",
      market: "Market",
      contact: "Contact",
      cta: "Assess feasibility",
      subBrand: "Cross-Border Enabler · TW⇆IN",
    },
    hero: {
      tag: "Commissioned by Indian sovereign and conglomerate stakeholders",
      h1a: "Bridging Taiwan Tech & India Capability: Your trusted ",
      h1em: "gateway",
      h1b: " for semiconductor localization.",
      sub: "TINMAN formats and de-risks cross-border relocation through an elite dual-network of industry experts — sourcing premium Taiwanese suppliers on behalf of Indian authorities and leading conglomerates.",
      cta1: "Assess your feasibility",
      cta2: "Explore expert network",
    },
    why: {
      eyebrow: "Why TINMAN",
      h2a: "De-risking cross-border expansion via ",
      h2em: "structural compliance",
      h2b: ".",
      lede: "Three layers of risk — policy, technical, and operational — handled by experts who have done it before. We engineer certainty into a market where most foreign entrants stall at year one.",
      cards: [
        { kind: "Policy de-risking", title: "Authorized Sovereign Policy Interface",
          body: "Directly backed by India's central and state-level investment initiatives. We secure hard commitments on subsidies (PLI / ISM) and dedicated land allocations in industrial zones — insulating your business from regulatory volatility." },
        { kind: "Technical de-risking", title: "Semiconductor Expert Due Diligence",
          body: "We deploy veteran Taiwanese fab directors and process/facility engineers to evaluate local infrastructure — ensuring water, power, and supply chain readiness before you break ground." },
        { kind: "Operational de-risking", title: "Turnkey Cross-Border Project Management",
          body: "We integrate local legal, tax, and Government Relations specialists in India under a single, Mandarin-speaking management window that aligns with Taiwanese corporate velocity." },
      ],
    },
    cap: {
      eyebrow: "Our capabilities",
      h2a: "Four mandates. ",
      h2em: "One management window.",
      h2b: "",
      ghostCta: "Discuss a mandate",
      engage: "Engage",
      rows: [
        { title: "India Market Feasibility & Strategic Site Selection",
          pillars: ["Market entry", "Site survey", "Cost modeling"],
          blurb: "Quantified entry models — utilities, talent, logistics — mapped against eight candidate industrial parks." },
        { title: "Cross-Border JV Structuring & Negotiation Facilitation",
          pillars: ["JV", "Term sheets", "IP protection"],
          blurb: "Term-sheet architecture aligned with both Taiwanese fab culture and Indian conglomerate governance." },
        { title: "Federal (ISM / PLI) & State Subsidy Application & GR Maintenance",
          pillars: ["ISM", "PLI", "State liaison"],
          blurb: "End-to-end application drafting, defense, and ongoing government-relations maintenance through disbursement." },
        { title: "Semiconductor Process Tech-Transfer SOP Localization & Talent Enablement",
          pillars: ["SOP", "Training", "Yield ramp"],
          blurb: "Localized SOPs, operator certification pathways, and a Hsinchu-to-host-site mentoring schedule for yield ramp." },
      ],
    },
    about: {
      eyebrow: "About TINMAN",
      h2a: "The ",
      h2em: "premier",
      h2b: " Taiwan–India semiconductor cross-border integrator.",
      p1: 'TINMAN TRADING is established as the premier "Taiwan–India Semiconductor Cross-Border Enabler & Ecosystem Integrator." Understanding the inherent caution of Taiwan\'s mid-stream and downstream semiconductor supply chain regarding overseas expansion, we operate strictly to ',
      p1em: "minimize the cost of trust",
      p1b: ".",
      edgeLabel: "Our edge",
      edgeBody: "We don't develop technology ourselves. We act as a high-value systems integrator holding the keys to two critical resources: Taiwanese engineering experts who speak the language of the fab, and Indian policy experts who navigate the local bureaucratic and commercial landscape.",
      network: {
        tw: {
          name: "Taiwanese Expert Pool",
          role: "Tech · Process · Facilities",
          flag: "TW",
          heading: "Composed of senior alumni from Hsinchu / Tainan Science Parks",
          roles: [
            { title: "Retired Fab Directors", where: "TSMC · UMC · Powerchip alumni" },
            { title: "Senior Process Engineers", where: "Lithography · Etch · Deposition specializations" },
            { title: "Facility / Hook-up Heads", where: "Cleanroom · Water · UPW · Gas systems" },
            { title: "Equipment & Material Liaisons", where: "Hidden-champion supplier coordination" },
          ],
        },
        in: {
          name: "Indian Expert Pool",
          role: "Policy · Legal · GR",
          flag: "IN",
          heading: "Composed of former sovereign bureaucrats and category-specialist counsel",
          roles: [
            { title: "Former Sovereign Bureaucrats", where: "MeitY · ISM · State investment boards" },
            { title: "Legal Counsel — Semiconductor", where: "MeitY / ISM framework specialists" },
            { title: "Labor & Tax Compliance Experts", where: "Multi-state operational coverage" },
            { title: "Industrial Park Liaisons", where: "Dholera · Sanand · Bangalore corridor" },
          ],
        },
      },
    },
    market: {
      eyebrow: "Why India · why now",
      h2a: "Capitalizing on India's semiconductor ",
      h2em: "national strategy",
      h2b: ".",
      p1: "Driven by active mandates from Indian government bodies and industrial giants seeking reliable supply chains, TINMAN provides a green-channel entry.",
      p2: "This is the optimal window for Taiwanese equipment, materials, and component hidden champions to enter the Indian market with maximum sovereign backing.",
      cta: "Initiate strategy session",
      stats: [
        { num: "$10", numEm: "B+", lbl: "ISM outlay envelope", src: "India Semiconductor Mission" },
        { num: "50%", numEm: "", lbl: "Capex incentive ceiling", src: "Federal · ISM 2.0" },
        { num: "5", numEm: "+", lbl: "State-level co-incentives", src: "Gujarat · UP · TN · KA · MH" },
        { num: "2030", numEm: "", lbl: "National strategic horizon", src: "$110 B target market" },
      ],
    },
    contact: {
      eyebrow: "Contact",
      h2a: "Mitigating risks. ",
      h2em: "Accelerating",
      h2b: " semiconductor localization.",
      offices: [
        { k: "Taipei · HQ", v1: "Xinyi District", v2: "Mon–Fri · 09:00–18:00 CST · +886 (0)2 –" },
        { k: "Hsinchu · Tech", v1: "Hsinchu Science Park vicinity", v2: "Fab-engineer hub · by appointment" },
        { k: "New Delhi · GR", v1: "Connaught Place corridor", v2: "Mon–Fri · 09:30–18:30 IST · +91 (0)11 –" },
        { k: "Engagement", v1: "strategy@tinman-trading.co", isEmail: true },
      ],
    },
    form: {
      tag: "Strategy intake",
      title: "Initiate your Taiwan–India semiconductor strategy.",
      sub: "All submissions are reviewed under NDA. Average partner response: 2 business days.",
      f: {
        company: "Company name",
        contact: "Contact person",
        title: "Title",
        email: "Work email",
        sector: "Sector / industry segment",
        focus: "Core focus / requirements",
        timeline: "Target timeline",
        office: "Preferred office",
        notes: "Additional notes",
      },
      ph: {
        company: "e.g. Hsinchu Semicon Materials Co.",
        contact: "Full name",
        title: "e.g. VP, Overseas Strategy",
        email: "name@company.com",
        sectorDefault: "Select a sector…",
        notes: "Anything else we should know before our first call.",
      },
      sectors: ["Equipment Manufacturing", "Material Supply", "Facility Engineering", "Component / IDM", "Design / IP", "Other"],
      focus: ["Subsidy evaluation", "JV partner sourcing", "Site inspection", "Tech-transfer SOP"],
      timelines: ["Not yet defined", "Within 6 months", "6–12 months", "12–24 months", "Exploratory"],
      offices: ["Any", "Taipei", "Hsinchu", "New Delhi"],
      foot: "By submitting you agree to be contacted under standard NDA terms.",
      submit: "Initiate strategy review",
      success: {
        tag: "Submitted",
        title: "Strategy intake received.",
        body: "A senior partner will respond within two business days from our Taipei office to schedule a confidential feasibility review.",
        ref: "Engagement reference",
      },
      errors: {
        required: "Required",
        email: "Looks off — check the address",
        sector: "Pick a sector",
        focus: "Pick at least one focus",
      },
    },
    footer: {
      brand: "TINMAN TRADING",
      brandSuffix: "Co., Ltd.",
      desc: "Taiwan–India Semiconductor Cross-Border Enabler & Ecosystem Integrator. Mitigating risks, accelerating semiconductor localization.",
      capH: "Capabilities",
      capLinks: ["Feasibility & site selection", "JV structuring", "ISM / PLI subsidy", "Tech-transfer SOP"],
      companyH: "Company",
      companyLinks: ["About", "Expert network", "Market dynamics", "Press & partnerships"],
      officesH: "Offices",
      locs: [
        { code: "TPE", city: "Taipei", addr: "Headquarters" },
        { code: "HSC", city: "Hsinchu", addr: "Technical office" },
        { code: "NDL", city: "New Delhi", addr: "Government relations" },
      ],
      copyright: "© 2026 TINMAN TRADING CO., LTD. All rights reserved.",
      legal: ["Privacy", "Terms", "NDA framework"],
    },
  },

  zh: {
    nav: {
      why: "我們的價值",
      cap: "核心服務",
      about: "關於我們",
      market: "市場洞察",
      contact: "聯繫我們",
      cta: "啟動可行性評估",
      subBrand: "台印半導體跨境整合 · TW⇆IN",
    },
    hero: {
      tag: "受印度官方與龍頭企業共同委託",
      h1a: "連結台灣技術與印度製造能量，您信賴的半導體在地化",
      h1em: "樞紐",
      h1b: "。",
      sub: "TINMAN 以菁英級雙國專家網絡為核心，為印度政府與龍頭企業甄選頂尖台灣供應商，並協助規劃、降低跨境設廠風險。",
      cta1: "啟動可行性評估",
      cta2: "認識專家網絡",
    },
    why: {
      eyebrow: "我們的價值",
      h2a: "以",
      h2em: "結構性合規",
      h2b: "化解跨境擴張的三大風險。",
      lede: "政策、技術、營運三大風險層級，由實戰經驗豐富的專家全面處理。在多數外商一年內停滯的市場中，我們為您構築確定性。",
      cards: [
        { kind: "政策風險", title: "主權級政策直通窗口",
          body: "由印度中央與邦級投資機構直接背書，鎖定 PLI／ISM 補貼與工業園區土地分配的明確承諾，協助您隔絕政策波動風險。" },
        { kind: "技術風險", title: "半導體專家實地盡職調查",
          body: "派遣資深台灣晶圓廠廠長與製程、廠務工程師，於動工前完成水、電、供應鏈整備度的全面評估。" },
        { kind: "營運風險", title: "一站式跨境專案管理",
          body: "整合印度當地法律、稅務與政府關係專家，由華語管理窗口統籌，全程配合台廠決策節奏。" },
      ],
    },
    cap: {
      eyebrow: "核心服務",
      h2a: "四大專案。",
      h2em: "一個窗口統籌。",
      h2b: "",
      ghostCta: "洽談合作項目",
      engage: "立即洽詢",
      rows: [
        { title: "印度市場可行性研究與策略選址",
          pillars: ["市場進入", "場勘評估", "成本建模"],
          blurb: "量化進入模型 — 公用事業、人才、物流 — 對應八個候選工業園區。" },
        { title: "跨境合資結構設計與談判協助",
          pillars: ["合資", "條款書", "智財保護"],
          blurb: "兼容台廠製造文化與印度集團治理規範的條款架構設計。" },
        { title: "聯邦（ISM／PLI）與邦級補貼申請及政府關係維護",
          pillars: ["ISM", "PLI", "邦級聯絡"],
          blurb: "從申請撰寫、答辯到撥款，提供全程政府關係維護。" },
        { title: "半導體製程技轉 SOP 在地化與人才培育",
          pillars: ["SOP", "培訓", "良率爬升"],
          blurb: "在地化 SOP、操作員認證路徑，以及新竹至駐地的師徒制培訓排程。" },
      ],
    },
    about: {
      eyebrow: "關於 TINMAN",
      h2a: "台印半導體跨境合作的",
      h2em: "領先",
      h2b: "整合平台。",
      p1: "TINMAN TRADING 致力成為「台印半導體跨境合作與生態系整合者」的領導品牌。我們深知台灣中下游半導體供應鏈對海外擴張的審慎態度，因此嚴守原則 — 為您",
      p1em: "將信任成本降至最低",
      p1b: "。",
      edgeLabel: "我們的優勢",
      edgeBody: "我們不自行開發技術。我們以高價值系統整合者的身份，掌握兩項關鍵資源：能說晶圓廠語言的台灣工程專家，以及熟悉印度官僚與商業環境的政策專家。",
      network: {
        tw: {
          name: "台灣專家庫",
          role: "技術 · 製程 · 廠務",
          flag: "TW",
          heading: "由新竹／台南科學園區資深專家組成",
          roles: [
            { title: "退休晶圓廠廠長", where: "台積電 · 聯電 · 力晶資深經歷" },
            { title: "資深製程工程師", where: "微影 · 蝕刻 · 沉積專業領域" },
            { title: "廠務／系統建置主管", where: "無塵室 · 水資源 · UPW · 氣體系統" },
            { title: "設備與材料聯絡窗口", where: "隱形冠軍供應商整合協調" },
          ],
        },
        in: {
          name: "印度專家庫",
          role: "政策 · 法務 · 政府關係",
          flag: "IN",
          heading: "由前主權機構官員與專業領域顧問組成",
          roles: [
            { title: "前主權機構官員", where: "MeitY · ISM · 各邦投資委員會" },
            { title: "半導體法律顧問", where: "MeitY／ISM 制度專家" },
            { title: "勞工與稅務合規專家", where: "跨邦營運合規涵蓋" },
            { title: "工業園區聯絡窗口", where: "Dholera · Sanand · 班加羅爾走廊" },
          ],
        },
      },
    },
    market: {
      eyebrow: "為何選擇印度 · 為何是現在",
      h2a: "把握印度",
      h2em: "國家半導體戰略",
      h2b: "的黃金窗口。",
      p1: "在印度政府單位與工業巨擘積極徵召可靠供應鏈的浪潮下，TINMAN 為您提供綠色通道式進入策略。",
      p2: "對台灣設備、材料與零組件的「隱形冠軍」而言，現在正是以最大主權級支持進入印度市場的最佳時點。",
      cta: "啟動策略會議",
      stats: [
        { num: "$100", numEm: "億+", lbl: "ISM 投資規模", src: "印度半導體任務" },
        { num: "50%", numEm: "", lbl: "資本支出補貼上限", src: "聯邦 · ISM 2.0" },
        { num: "5", numEm: "+", lbl: "邦級加碼補貼", src: "古吉拉特 · UP · TN · KA · MH" },
        { num: "2030", numEm: "", lbl: "國家戰略時程", src: "1,100 億美元目標市場" },
      ],
    },
    contact: {
      eyebrow: "聯繫我們",
      h2a: "降低風險。",
      h2em: "加速",
      h2b: "半導體在地化。",
      offices: [
        { k: "台北 · 總部", v1: "信義區", v2: "週一至週五 · 09:00–18:00 CST · +886 (0)2 –" },
        { k: "新竹 · 技術", v1: "新竹科學園區周邊", v2: "晶圓專家集散地 · 採預約制" },
        { k: "新德里 · 政府關係", v1: "康諾特廣場核心區", v2: "週一至週五 · 09:30–18:30 IST · +91 (0)11 –" },
        { k: "業務聯繫", v1: "strategy@tinman-trading.co", isEmail: true },
      ],
    },
    form: {
      tag: "策略諮詢",
      title: "啟動您的台印半導體策略。",
      sub: "所有提交內容均於保密協議下審閱。合夥人平均回應時間：2 個工作天。",
      f: {
        company: "公司名稱",
        contact: "聯絡人",
        title: "職稱",
        email: "公司信箱",
        sector: "產業類別",
        focus: "核心需求",
        timeline: "預計時程",
        office: "偏好辦公室",
        notes: "補充說明",
      },
      ph: {
        company: "例：新竹半導體材料股份有限公司",
        contact: "完整姓名",
        title: "例：海外策略副總",
        email: "name@company.com",
        sectorDefault: "請選擇產業類別…",
        notes: "第一次聯繫前，還有任何需要我們了解的資訊嗎？",
      },
      sectors: ["設備製造", "材料供應", "廠務工程", "零件 / IDM", "設計 / IP", "其他"],
      focus: ["補貼評估", "合資夥伴媒合", "場勘調查", "技轉 SOP"],
      timelines: ["尚未確定", "6 個月內", "6–12 個月", "12–24 個月", "探索評估中"],
      offices: ["不限", "台北", "新竹", "新德里"],
      foot: "提交即表示您同意以標準保密協議方式接受聯繫。",
      submit: "啟動策略審查",
      success: {
        tag: "已提交",
        title: "策略諮詢已收到。",
        body: "資深合夥人將於兩個工作天內，由台北辦公室聯繫您，安排機密可行性審查。",
        ref: "諮詢參考編號",
      },
      errors: {
        required: "必填",
        email: "格式有誤 — 請檢查信箱",
        sector: "請選擇產業類別",
        focus: "請至少選擇一項",
      },
    },
    footer: {
      brand: "TINMAN TRADING",
      brandSuffix: "股份有限公司",
      desc: "台印半導體跨境合作與生態系整合者。降低風險，加速半導體在地化。",
      capH: "核心服務",
      capLinks: ["可行性研究與選址", "合資結構設計", "ISM／PLI 補貼", "技轉 SOP"],
      companyH: "公司",
      companyLinks: ["關於我們", "專家網絡", "市場洞察", "媒體與合作"],
      officesH: "辦公室",
      locs: [
        { code: "TPE", city: "台北", addr: "總部" },
        { code: "HSC", city: "新竹", addr: "技術辦公室" },
        { code: "NDL", city: "新德里", addr: "政府關係" },
      ],
      copyright: "© 2026 TINMAN TRADING 股份有限公司。版權所有。",
      legal: ["隱私權", "服務條款", "保密協議框架"],
    },
  },
};

const LangCtx = React.createContext({ lang: "en", t: translations.en, setLang: () => {} });

function LangProvider({ children }) {
  const [lang, setLangState] = React.useState(() => {
    try { return localStorage.getItem("tinman-lang") || "en"; } catch (e) { return "en"; }
  });
  React.useEffect(() => {
    try { localStorage.setItem("tinman-lang", lang); } catch (e) {}
    document.documentElement.lang = lang === "zh" ? "zh-TW" : "en";
    document.body.setAttribute("data-lang", lang);
  }, [lang]);
  return (
    <LangCtx.Provider value={{ lang, t: translations[lang], setLang: setLangState }}>
      {children}
    </LangCtx.Provider>
  );
}

function useLang() {
  return React.useContext(LangCtx);
}

window.LangProvider = LangProvider;
window.useLang = useLang;
window.TINTranslations = translations;

// TINMAN — main app shell wiring all sections + Tweaks
const { useEffect: useEffectA } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "emphasis": "slate",
  "motif": "corridor",
  "headline": "sans",
  "containerWidth": 1240
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffectA(() => {
    document.body.setAttribute("data-emphasis", t.emphasis);
    document.body.setAttribute("data-headline", t.headline);
    document.documentElement.style.setProperty("--container", `${t.containerWidth}px`);
  }, [t.emphasis, t.headline, t.containerWidth]);

  return (
    <React.Fragment>
      <Header />
      <main>
        <Hero motif={t.motif} />
        <Why />
        <Capabilities />
        <About />
        <Market />
        <Contact />
      </main>
      <Footer />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Visual emphasis">
          <TweakRadio
            label="Color"
            value={t.emphasis}
            options={[
              { value: "slate", label: "Slate-led" },
              { value: "amber", label: "Amber-led" },
            ]}
            onChange={(v) => setTweak("emphasis", v)}
          />
          <TweakRadio
            label="Headline"
            value={t.headline}
            options={[
              { value: "sans", label: "Sans" },
              { value: "serif", label: "Serif" },
            ]}
            onChange={(v) => setTweak("headline", v)}
          />
        </TweakSection>

        <TweakSection label="Layout">
          <TweakSlider
            label="Content width"
            value={t.containerWidth}
            min={1080}
            max={1440}
            step={20}
            unit="px"
            onChange={(v) => setTweak("containerWidth", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(
  <window.LangProvider>
    <App />
  </window.LangProvider>
);

// TINMAN TRADING — Sections (Header, Hero, Why, Capabilities, About, Network, Market, Contact, Footer)
// Loaded after React + Babel; exposes components on window for the main app file.

const { useState, useEffect, useRef, useMemo } = React;

/* ============== Icon set (Lucide-style, inline SVG) ============== */
const I = {
  arrow: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>,
  check: (p) => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="20 6 9 17 4 12" /></svg>,
  shield: (p) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /><path d="m9 12 2 2 4-4" /></svg>,
  cpu: (p) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="4" y="4" width="16" height="16" rx="2" /><rect x="9" y="9" width="6" height="6" /><path d="M15 2v2" /><path d="M15 20v2" /><path d="M2 15h2" /><path d="M2 9h2" /><path d="M20 15h2" /><path d="M20 9h2" /><path d="M9 2v2" /><path d="M9 20v2" /></svg>,
  workflow: (p) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="8" height="8" x="3" y="3" rx="2" /><path d="M7 11v4a2 2 0 0 0 2 2h4" /><rect width="8" height="8" x="13" y="13" rx="2" /></svg>,
  building: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="16" height="20" x="4" y="2" rx="2" /><path d="M9 22v-4h6v4" /><path d="M8 6h.01" /><path d="M16 6h.01" /><path d="M12 6h.01" /><path d="M12 10h.01" /><path d="M12 14h.01" /><path d="M16 10h.01" /><path d="M16 14h.01" /><path d="M8 10h.01" /><path d="M8 14h.01" /></svg>
};

/* ============== Reveal helper ============== */
function Reveal({ children, delay = 0, as = "div", ...rest }) {
  const ref = useRef(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {setVis(true);io.disconnect();}
    }, { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const Tag = as;
  return (
    <Tag ref={ref} className={(rest.className || "") + " reveal " + (vis ? "in" : "")} style={{ transitionDelay: vis ? `${delay}ms` : "0ms", ...(rest.style || {}) }}>
      {children}
    </Tag>);

}

/* ============== Header / Nav ============== */
function Header() {
  const [scrolled, setScrolled] = useState(false);
  const { t, lang, setLang } = useLang();
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className={"nav" + (scrolled ? " scrolled" : "")}>
      <div className="container nav-row">
        <a href="#top" className="logo">
          <span className="logo-mark">T</span>
          <span className="logo-name">
            <span className="co">TINMAN TRADING</span>
            <span className="sub">{t.nav.subBrand}</span>
          </span>
        </a>
        <nav className="nav-links">
          <a href="#why">{t.nav.why}</a>
          <a href="#capabilities">{t.nav.cap}</a>
          <a href="#about">{t.nav.about}</a>
          <a href="#market">{t.nav.market}</a>
          <a href="#contact">{t.nav.contact}</a>
        </nav>
        <div className="nav-right">
          <div className="lang-switch" role="group" aria-label="Language">
            <button
              className={"lang-btn" + (lang === "en" ? " is-active" : "")}
              onClick={() => setLang("en")}
              aria-pressed={lang === "en"}
            >EN</button>
            <span className="lang-sep">/</span>
            <button
              className={"lang-btn" + (lang === "zh" ? " is-active" : "")}
              onClick={() => setLang("zh")}
              aria-pressed={lang === "zh"}
            >中</button>
          </div>
          <a href="#contact" className="btn btn-amber">{t.nav.cta} <span className="arrow"><I.arrow /></span></a>
        </div>
      </div>
    </header>);

}

/* ============== Hero corridor visual ============== */
function CorridorMap({ motif = "corridor" }) {
  // 480x500 coordinate system
  const tw = { x: 132, y: 200, label: "Taipei · Hsinchu" };
  const in_ = { x: 372, y: 304, label: "New Delhi" };
  // intermediate route points (curve)
  const cx = 252,cy = 360;

  if (motif === "circuit") {
    return (
      <svg viewBox="0 0 480 500" preserveAspectRatio="xMidYMid slice">
        {/* wafer */}
        <circle cx="240" cy="250" r="170" fill="#0F172A" />
        <circle cx="240" cy="250" r="170" fill="none" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
        <circle cx="240" cy="250" r="120" fill="none" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
        <circle cx="240" cy="250" r="70" fill="none" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
        {/* notch */}
        <path d="M 240 80 l -10 8 l 20 0 z" fill="#0F172A" stroke="#334155" />
        {/* circuit lines */}
        {[80, 100, 120, 140, 160].map((r, i) =>
        <g key={i} opacity={0.5 + i * 0.08}>
            <path d={`M ${240 - r} 250 L ${240 - r + 18} 250 L ${240 - r + 26} 258 L ${240 - r + 60} 258`} fill="none" stroke="#B45309" strokeWidth="1" />
            <circle cx={240 - r + 60} cy={258} r="2" fill="#F59E0B" />
          </g>
        )}
        {[80, 110, 140].map((r, i) =>
        <g key={i}>
            <path d={`M ${240 + r} 250 L ${240 + r - 18} 250 L ${240 + r - 26} 242 L ${240 + r - 80} 242`} fill="none" stroke="#38BDF8" strokeWidth="1" opacity="0.8" />
            <circle cx={240 + r - 80} cy={242} r="2" fill="#38BDF8" />
          </g>
        )}
        {/* center logo */}
        <g transform="translate(240 250)">
          <rect x="-20" y="-20" width="40" height="40" rx="6" fill="#0B1220" stroke="#B45309" strokeWidth="1" />
          <text x="0" y="6" textAnchor="middle" fontFamily="Instrument Serif, serif" fontSize="22" fill="#F59E0B" fontStyle="italic">T</text>
        </g>
        <text x="240" y="450" textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="9" fill="#64748B" letterSpacing="0.2em">SEMICONDUCTOR · LOCALIZATION · CORE</text>
      </svg>);

  }

  if (motif === "grid") {
    const cells = [];
    for (let r = 0; r < 9; r++) for (let c = 0; c < 9; c++) {
      const filled = (r + c) % 3 === 0;
      const accent = r === 4 && c === 4 || r === 4 && c === 5 || r === 3 && c === 4;
      cells.push(
        <rect key={`${r}-${c}`} x={40 + c * 44} y={40 + r * 44} width="36" height="36"
        fill={accent ? "#B45309" : filled ? "#0F172A" : "#E2E8F0"}
        opacity={accent ? 1 : filled ? 0.9 : 0.5} />
      );
    }
    return (
      <svg viewBox="0 0 480 500" preserveAspectRatio="xMidYMid meet">
        {cells}
        <text x="60" y="470" fontFamily="IBM Plex Mono, monospace" fontSize="9" fill="#64748B" letterSpacing="0.2em">DUAL-NETWORK · INDEX</text>
        <text x="420" y="470" textAnchor="end" fontFamily="IBM Plex Mono, monospace" fontSize="9" fill="#64748B" letterSpacing="0.2em">9 × 9 · 81 NODES</text>
      </svg>);

  }

  // default: corridor map
  return (
    <svg viewBox="0 0 480 500" preserveAspectRatio="xMidYMid meet">
      <defs>
        <linearGradient id="routeg" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#0F172A" />
          <stop offset="100%" stopColor="#B45309" />
        </linearGradient>
      </defs>

      {/* lat/lng faint lines */}
      {[100, 200, 300, 400].map((y) =>
      <line key={y} x1="20" x2="460" y1={y} y2={y} stroke="#CBD5E1" strokeWidth="0.5" strokeDasharray="2 6" />
      )}
      {[80, 240, 400].map((x) =>
      <line key={x} y1="20" y2="480" x1={x} x2={x} stroke="#CBD5E1" strokeWidth="0.5" strokeDasharray="2 6" />
      )}

      {/* abstract continents — simplified Asia shapes */}
      <g fill="#0F172A" opacity="0.08">
        {/* India landmass */}
        <path d="M 320 200 Q 340 180 380 200 L 410 220 Q 420 260 405 300 L 380 340 Q 360 360 340 340 Q 320 320 320 280 Q 315 240 320 200 Z" />
        {/* Taiwan island */}
        <ellipse cx="132" cy="200" rx="14" ry="26" />
        {/* SE Asia stretch */}
        <path d="M 200 220 Q 240 230 260 260 Q 270 290 250 310 Q 220 320 200 300 Z" />
      </g>

      {/* the route arc */}
      <path d={`M ${tw.x} ${tw.y} Q ${cx} ${cy} ${in_.x} ${in_.y}`}
      fill="none" stroke="url(#routeg)" strokeWidth="1.8" opacity="0.95" />
      <path d={`M ${tw.x} ${tw.y} Q ${cx} ${cy} ${in_.x} ${in_.y}`}
      fill="none" stroke="#B45309" strokeWidth="1.8" className="route-line" opacity="0.6" />

      {/* TW node */}
      <g>
        <circle cx={tw.x} cy={tw.y} r="22" fill="#0F172A" />
        <circle cx={tw.x} cy={tw.y} r="22" fill="none" stroke="#0F172A" strokeOpacity="0.2" strokeWidth="12" />
        <text x={tw.x} y={tw.y + 4} textAnchor="middle" fontFamily="IBM Plex Sans, sans-serif" fontSize="10" fontWeight="600" fill="#F59E0B">TW</text>
        <text x={tw.x} y={tw.y - 36} textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="9" fill="#0F172A" letterSpacing="0.1em">{tw.label.toUpperCase()}</text>
        <text x={tw.x} y={tw.y + 50} textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="8" fill="#64748B">25.0°N · 121.5°E</text>
      </g>

      {/* IN node */}
      <g>
        <circle cx={in_.x} cy={in_.y} r="22" fill="#B45309" />
        <circle cx={in_.x} cy={in_.y} r="22" fill="none" stroke="#B45309" strokeOpacity="0.2" strokeWidth="12" />
        <text x={in_.x} y={in_.y + 4} textAnchor="middle" fontFamily="IBM Plex Sans, sans-serif" fontSize="10" fontWeight="600" fill="#fff">IN</text>
        <text x={in_.x} y={in_.y - 36} textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="9" fill="#0F172A" letterSpacing="0.1em">{in_.label.toUpperCase()}</text>
        <text x={in_.x} y={in_.y + 50} textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="8" fill="#64748B">28.6°N · 77.2°E</text>
      </g>

      {/* small partner nodes */}
      {[
      { x: 122, y: 250, l: "TPE" },
      { x: 152, y: 220, l: "HSC" },
      { x: 358, y: 340, l: "BLR" },
      { x: 390, y: 270, l: "AHM" }].
      map((n, i) =>
      <g key={i}>
          <circle cx={n.x} cy={n.y} r="3.5" fill="#fff" stroke="#0F172A" strokeWidth="1" />
          <text x={n.x + 8} y={n.y + 3} fontFamily="IBM Plex Mono, monospace" fontSize="7" fill="#64748B" letterSpacing="0.1em">{n.l}</text>
        </g>
      )}

      {/* mid-route compliance markers */}
      {[0.32, 0.55, 0.78].map((t, i) => {
        const x = (1 - t) * (1 - t) * tw.x + 2 * (1 - t) * t * cx + t * t * in_.x;
        const y = (1 - t) * (1 - t) * tw.y + 2 * (1 - t) * t * cy + t * t * in_.y;
        return (
          <g key={i}>
            <rect x={x - 4} y={y - 4} width="8" height="8" fill="#fff" stroke="#0F172A" strokeWidth="1" transform={`rotate(45 ${x} ${y})`} />
          </g>);

      })}
    </svg>);

}

/* ============== Hero ============== */
function Hero({ motif }) {
  const { t } = useLang();
  return (
    <section id="top" className="hero">
      <div className="container">
        <div className="hero-grid">
          <div>
          <Reveal>
            <div className="hero-tag">
              <span className="dot">·</span>
              {t.hero.tag}
            </div>
          </Reveal>
          <Reveal delay={60}>
            <h1>
              {t.hero.h1a}<em>{t.hero.h1em}</em>{t.hero.h1b}
            </h1>
          </Reveal>
          <Reveal delay={120}>
            <p className="hero-sub">
              {t.hero.sub}
            </p>
          </Reveal>
          <Reveal delay={180}>
            <div className="hero-ctas">
              <a href="#contact" className="btn btn-amber">{t.hero.cta1} <span className="arrow"><I.arrow /></span></a>
              <a href="#about" className="btn btn-secondary">{t.hero.cta2}</a>
            </div>
          </Reveal>
        </div>

      </div>
      </div>
    </section>);

}

/* ============== Why TINMAN ============== */
function Why() {
  const { t } = useLang();
  const glyphs = [<I.shield />, <I.cpu />, <I.workflow />];
  const cards = t.why.cards.map((c, i) => ({ ...c, glyph: glyphs[i] }));
  return (
    <section id="why" className="section why">
      <div className="container">
        <div className="why-head">
          <div>
            <Reveal><div className="eyebrow">{t.why.eyebrow}</div></Reveal>
            <Reveal delay={60}>
              <h2 style={{ marginTop: 18 }}>{t.why.h2a}<em>{t.why.h2em}</em>{t.why.h2b}</h2>
            </Reveal>
          </div>
          <Reveal delay={120}>
            <p className="lede">
              {t.why.lede}
            </p>
          </Reveal>
        </div>

        <div className="cards-3">
          {cards.map((c, i) =>
          <Reveal key={i} delay={i * 80}>
              <article className="derisk-card">
                <span className="idx">0{i + 1}</span>
                <span className="kind">{c.kind}</span>
                <div className="glyph">{c.glyph}</div>
                <h3>{c.title}</h3>
                <p>{c.body}</p>
              </article>
            </Reveal>
          )}
        </div>
      </div>
    </section>);

}

/* ============== Capabilities ============== */
function Capabilities() {
  const { t } = useLang();
  const nums = ["C·01", "C·02", "C·03", "C·04"];
  const rows = t.cap.rows.map((r, i) => ({ ...r, num: nums[i] }));

  return (
    <section id="capabilities" className="section cap">
      <div className="container">
        <div className="cap-head">
          <div>
            <Reveal><div className="eyebrow">{t.cap.eyebrow}</div></Reveal>
            <Reveal delay={60}><h2 style={{ marginTop: 18 }}>{t.cap.h2a}<em>{t.cap.h2em}</em>{t.cap.h2b}</h2></Reveal>
          </div>
          <Reveal delay={120}>
            <a href="#contact" className="btn btn-ghost">{t.cap.ghostCta} <span className="arrow"><I.arrow /></span></a>
          </Reveal>
        </div>
        <div className="cap-list">
          {rows.map((r, i) =>
          <Reveal key={i} delay={i * 60}>
              <div className="cap-row">
                <div className="cap-num">{r.num}</div>
                <h3>{r.title}</h3>
                <div className="blurb">{r.blurb}</div>
                <div className="pillars">{r.pillars.map((p, j) => <span key={j} className="pillar">{p}</span>)}</div>
                <a href="#contact" className="cap-cta">{t.cap.engage} <I.arrow /></a>
              </div>
            </Reveal>
          )}
        </div>
      </div>
    </section>);

}

/* ============== About + Network ============== */
function About() {
  const [tab, setTab] = useState("tw");
  const { t } = useLang();
  const pools = t.about.network;
  const active = pools[tab];

  return (
    <section id="about" className="section about">
      <div className="container">
        <div className="about-grid">
          <div>
            <Reveal><div className="eyebrow">{t.about.eyebrow}</div></Reveal>
            <Reveal delay={60}><h2 style={{ marginTop: 18 }}>{t.about.h2a}<em>{t.about.h2em}</em>{t.about.h2b}</h2></Reveal>
            <Reveal delay={120}>
              <div style={{ marginTop: 32 }}>
                <p>
                  {t.about.p1}<em>{t.about.p1em}</em>{t.about.p1b}
                </p>
              </div>
            </Reveal>
            <Reveal delay={180}>
              <div className="edge-callout">
                <div className="label">{t.about.edgeLabel}</div>
                <p>
                  {t.about.edgeBody}
                </p>
              </div>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <div className="network">
              <div className="network-tabs">
                {Object.entries(pools).map(([k, p]) =>
                <button
                  key={k}
                  className={"network-tab" + (tab === k ? " is-active" : "")}
                  onClick={() => setTab(k)}>
                  
                    <span className="flag">{p.flag}</span>
                    <span>
                      <span className="name">{p.name}</span>
                      <div className="role">{p.role}</div>
                    </span>
                  </button>
                )}
              </div>
              <div className="network-body">
                <h4>{active.heading}</h4>
                <div className="network-roles">
                  {active.roles.map((r, i) =>
                  <div key={i} className="network-role">
                      <div className="ord">{String(i + 1).padStart(2, "0")}</div>
                      <div>
                        <div className="title-line">{r.title}</div>
                        <div className="where">{r.where}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>);

}

/* ============== Market Dynamics ============== */
function Market() {
  const { t } = useLang();
  return (
    <section id="market" className="section market">
      <div className="container market-content">
        <div className="market-grid">
          <div>
            <Reveal><div className="eyebrow">{t.market.eyebrow}</div></Reveal>
            <Reveal delay={60}><h2 style={{ marginTop: 18 }}>{t.market.h2a}<em>{t.market.h2em}</em>{t.market.h2b}</h2></Reveal>
            <Reveal delay={120}>
              <div style={{ marginTop: 28 }}>
                <p>
                  {t.market.p1}
                </p>
                <p>
                  {t.market.p2}
                </p>
              </div>
            </Reveal>
            <Reveal delay={180}>
              <div style={{ marginTop: 36 }}>
                <a href="#contact" className="btn btn-amber">{t.market.cta} <span className="arrow"><I.arrow /></span></a>
              </div>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <div className="market-stats">
              {t.market.stats.map((s, i) =>
              <div key={i} className="market-stat">
                <div className="num">{s.num}{s.numEm ? <em>{s.numEm}</em> : null}</div>
                <div className="lbl">{s.lbl}</div>
                <div className="src">{s.src}</div>
              </div>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>);

}

window.Header = Header;
window.Hero = Hero;
window.Why = Why;
window.Capabilities = Capabilities;
window.About = About;
window.Market = Market;
window.Reveal = Reveal;
window.TINIcons = I;
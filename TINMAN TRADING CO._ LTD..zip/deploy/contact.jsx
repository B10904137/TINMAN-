// TINMAN — Contact form + Footer

const { useState: useStateC } = React;
const ICONS = window.TINIcons;
const RevealC = window.Reveal;

function ContactForm() {
  const { t } = window.useLang();
  const [data, setData] = useStateC({
    company: "",
    contact: "",
    title: "",
    email: "",
    sector: "",
    focus: [],
    timeline: "",
    notes: "",
  });
  const [errors, setErrors] = useStateC({});
  const [done, setDone] = useStateC(false);

  const set = (k, v) => setData(d => ({ ...d, [k]: v }));
  const toggleFocus = (f) =>
    setData(d => ({ ...d, focus: d.focus.includes(f) ? d.focus.filter(x => x !== f) : [...d.focus, f] }));

  const submit = (e) => {
    e.preventDefault();
    const err = {};
    if (!data.company.trim()) err.company = t.form.errors.required;
    if (!data.contact.trim()) err.contact = t.form.errors.required;
    if (!data.email.trim()) err.email = t.form.errors.required;
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) err.email = t.form.errors.email;
    if (!data.sector) err.sector = t.form.errors.sector;
    if (data.focus.length === 0) err.focus = t.form.errors.focus;
    setErrors(err);
    if (Object.keys(err).length === 0) setDone(true);
  };

  if (done) {
    const ref = "TIN-" + new Date().getFullYear() + "-" + Math.random().toString(36).slice(2, 7).toUpperCase();
    return (
      <div className="form">
        <div className="ftag">{t.form.success.tag}</div>
        <div className="form-success">
          <h4>{t.form.success.title}</h4>
          <p>{t.form.success.body}</p>
          <div className="ref">
            <span>{t.form.success.ref}</span>
            <span>{ref}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form className="form" onSubmit={submit} noValidate>
      <div className="ftag">{t.form.tag}</div>
      <div className="title">{t.form.title}</div>
      <div className="sub">{t.form.sub}</div>

      <div className="form-grid">
        <div className={"field" + (errors.company ? " error" : "")}>
          <label>{t.form.f.company} <span className="req">*</span></label>
          <input type="text" value={data.company} onChange={(e) => set("company", e.target.value)} placeholder={t.form.ph.company} />
          {errors.company && <div className="err-msg">{errors.company}</div>}
        </div>
        <div className={"field" + (errors.contact ? " error" : "")}>
          <label>{t.form.f.contact} <span className="req">*</span></label>
          <input type="text" value={data.contact} onChange={(e) => set("contact", e.target.value)} placeholder={t.form.ph.contact} />
          {errors.contact && <div className="err-msg">{errors.contact}</div>}
        </div>

        <div className="field">
          <label>{t.form.f.title}</label>
          <input type="text" value={data.title} onChange={(e) => set("title", e.target.value)} placeholder={t.form.ph.title} />
        </div>
        <div className={"field" + (errors.email ? " error" : "")}>
          <label>{t.form.f.email} <span className="req">*</span></label>
          <input type="email" value={data.email} onChange={(e) => set("email", e.target.value)} placeholder={t.form.ph.email} />
          {errors.email && <div className="err-msg">{errors.email}</div>}
        </div>

        <div className={"field full" + (errors.sector ? " error" : "")}>
          <label>{t.form.f.sector} <span className="req">*</span></label>
          <select value={data.sector} onChange={(e) => set("sector", e.target.value)}>
            <option value="">{t.form.ph.sectorDefault}</option>
            {t.form.sectors.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          {errors.sector && <div className="err-msg">{errors.sector}</div>}
        </div>

        <div className={"field full" + (errors.focus ? " error" : "")}>
          <label>{t.form.f.focus} <span className="req">*</span></label>
          <div className="checkgrid">
            {t.form.focus.map(f => {
              const checked = data.focus.includes(f);
              return (
                <div
                  key={f}
                  className={"checkitem" + (checked ? " is-checked" : "")}
                  onClick={() => toggleFocus(f)}
                  role="checkbox"
                  aria-checked={checked}
                  tabIndex={0}
                  onKeyDown={(e) => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); toggleFocus(f); } }}
                >
                  <span className="box"><ICONS.check /></span>
                  <span>{f}</span>
                </div>
              );
            })}
          </div>
          {errors.focus && <div className="err-msg">{errors.focus}</div>}
        </div>

        <div className="field">
          <label>{t.form.f.timeline}</label>
          <select value={data.timeline} onChange={(e) => set("timeline", e.target.value)}>
            {t.form.timelines.map((tl, i) => i === 0
              ? <option key={tl} value="">{tl}</option>
              : <option key={tl}>{tl}</option>)}
          </select>
        </div>
        <div className="field">
          <label>{t.form.f.office}</label>
          <select value={data.office || ""} onChange={(e) => set("office", e.target.value)}>
            {t.form.offices.map((o, i) => i === 0
              ? <option key={o} value="">{o}</option>
              : <option key={o}>{o}</option>)}
          </select>
        </div>

        <div className="field full">
          <label>{t.form.f.notes}</label>
          <textarea value={data.notes} onChange={(e) => set("notes", e.target.value)} placeholder={t.form.ph.notes} />
        </div>
      </div>

      <div className="submit-row">
        <span className="footer-note">{t.form.foot}</span>
        <button type="submit" className="btn btn-amber">
          {t.form.submit} <span className="arrow"><ICONS.arrow /></span>
        </button>
      </div>
    </form>
  );
}

function Contact() {
  const { t } = window.useLang();
  return (
    <section id="contact" className="section contact">
      <div className="container">
        <div className="contact-grid">
          <div>
            <RevealC><div className="eyebrow">{t.contact.eyebrow}</div></RevealC>
            <RevealC delay={60}><h2 style={{ marginTop: 18 }}>{t.contact.h2a}<em>{t.contact.h2em}</em>{t.contact.h2b}</h2></RevealC>

            <RevealC delay={120}>
              <div className="contact-info">
                {t.contact.offices.map((o, i) => (
                  <div className="row" key={i}>
                    <div className="k">{o.k}</div>
                    <div className="v">
                      {o.isEmail
                        ? <a href={`mailto:${o.v1}`} style={{ borderBottom: "1px solid var(--amber-700)", color: "var(--slate-900)" }}>{o.v1}</a>
                        : (<>{o.v1}<br /><span className="muted">{o.v2}</span></>)
                      }
                    </div>
                  </div>
                ))}
              </div>
            </RevealC>
          </div>

          <RevealC delay={120}>
            <ContactForm />
          </RevealC>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const { t } = window.useLang();
  return (
    <footer className="foot">
      <div className="container">
        <div className="foot-grid">
          <div className="foot-col foot-brand">
            <div className="lg-line">{t.footer.brand} <span style={{ color: "var(--amber-500)", fontFamily: "var(--font-serif)", fontStyle: "italic", fontWeight: 400 }}>{t.footer.brandSuffix}</span></div>
            <p>{t.footer.desc}</p>
          </div>

          <div className="foot-col">
            <h5>{t.footer.capH}</h5>
            <ul>
              {t.footer.capLinks.map((l, i) => <li key={i}><a href="#capabilities">{l}</a></li>)}
            </ul>
          </div>

          <div className="foot-col">
            <h5>{t.footer.companyH}</h5>
            <ul>
              {t.footer.companyLinks.map((l, i) => {
                const targets = ["#about", "#about", "#market", "#contact"];
                return <li key={i}><a href={targets[i] || "#"}>{l}</a></li>;
              })}
            </ul>
          </div>

          <div className="foot-col">
            <h5>{t.footer.officesH}</h5>
            <div className="foot-locations">
              {t.footer.locs.map((loc, i) => (
                <div className="foot-loc" key={i}>
                  <div className="city"><span style={{ color: "var(--amber-500)", marginRight: 6, fontFamily: "var(--font-mono)", fontSize: 11 }}>{loc.code}</span>{loc.city}</div>
                  <div className="addr">{loc.addr}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="foot-bottom">
          <div>{t.footer.copyright}</div>
          <div className="legal">
            {t.footer.legal.map((l, i) => <a key={i} href="#">{l}</a>)}
          </div>
        </div>
      </div>
    </footer>
  );
}

window.Contact = Contact;
window.Footer = Footer;
